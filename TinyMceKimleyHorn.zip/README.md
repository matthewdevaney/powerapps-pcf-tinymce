# PCF.TinyMCE

PCF to convert Multiline text field in Dynamics 365/PowerApps Model Driven as rich text editor using TinyMCE libray
